
class boolLatch:
    def __init__ (self, bool_I_modeSetReset, bool_I_modeResetSet):
        self.bool_modeSetReset = bool_I_modeSetReset
        self.bool_modeResetSet = bool_I_modeResetSet
        self.bool_status = False
        if self.bool_modeSetReset == False and self.bool_modeResetSet == False:
            self.bool_modeSetReset = True           
        
    def changeLatchStatus(self, bool_I_cmdSet, bool_I_cmdReset):
        if self.bool_modeSetReset == True:
            if bool_I_cmdSet == True and bool_I_cmdReset == False:
                self.bool_status = True
            elif bool_I_cmdSet == True and bool_I_cmdReset == True:
                self.bool_status = False
            elif bool_I_cmdSet == False and bool_I_cmdReset == True:
                self.bool_status = False
            elif bool_I_cmdSet == False and bool_I_cmdReset == False:
                pass
        elif self.bool_modeResetSet == True:
            if bool_I_cmdSet == True and bool_I_cmdReset == False:
                self.bool_status = True
            elif bool_I_cmdSet == True and bool_I_cmdReset == True:
                self.bool_status = True
            elif bool_I_cmdSet == False and bool_I_cmdReset == True:
                self.bool_status = False
            elif bool_I_cmdSet == False and bool_I_cmdReset == False:
                pass
            
class edgeDetection:
    def __init__(self, bool_I_mode):
        self.bool_I_mode = bool_I_mode
        self.bool_memory = False
        self.bool_Q_outPut = False
        
    def queryEdgeStatus(self, bool_I_input):
        if self.bool_I_mode == True:
            if bool_I_input == True and self.bool_memory == False:
                self.bool_Q_outPut = True
            else:
                self.bool_Q_outPut = False
            if bool_I_input == True:
                self.bool_memory = True
            else:
                self.bool_memory = False
        elif self.bool_I_mode == False:
            if bool_I_input == False and self.bool_memory == True:
                self.bool_Q_outPut = True
            else:
                self.bool_Q_outPut = False
            if bool_I_input == True:
                self.bool_memory = True
            else:
                self.bool_memory = False
        return self.bool_Q_outPut
            

    


