import sys
sys.path.append('/extModules')

import _classBitLogic

edgeDetection = _classBitLogic.edgeDetection

class addIntegerWithRisingEdge(edgeDetection):
    def __init__(self, min, max):
        self.min = min
        self.max = max
        self.count = min
        
        edgeDetection.__init__(self, True, False)
        
    def addInteger(self, command):
        state = self.run(command)
        if state == True:
            if self.count >= self.max:
               self.count = self.min
            elif self.count < self.max:
               self.count += 1
            temp = self.count
        return temp
        
