import time
import sys
sys.path.append('/extModules')
import _classBitLogic
edgeDetection = _classBitLogic.edgeDetection

class timer:
    def __init__ (self):
        self.int_totalRuntime_ms = 0
        self.bool_stRunning = False
        self.bool_stOutput = False
        self.int_startTime_ms = 0
        self.int_runTime_ms = 0
    
    def initialize(self, int_I_delay_m, int_I_delay_s, int_I_delay_ms):
        self.int_totalRuntime_ms = int_I_delay_m * 60000 + int_I_delay_s * 1000 + int_I_delay_ms
        self.int_startTime_ms = time.ticks_ms()
    
    def updateRunTime(self):
        int_currentTime_ms = time.ticks_ms()
        self.int_runTime_ms = int_currentTime_ms - self.int_startTime_ms
        
    def reset(self):
        self.int_totalRuntime_ms = 0
        self.bool_stRunning = False
        self.bool_stOutput = False
        self.int_startTime_ms = 0
        self.int_runTime_ms = 0
        self.bool_memoryBit = False
        

class onDelayTimer(timer):
    def __init__(self):
        timer.__init__(self)
        
    def run(self, bool_I_cmdStart, int_I_delay_m, int_I_delay_s, int_I_delay_ms):
        if bool_I_cmdStart == True:
            if self.bool_stRunning == False and self.bool_stOutput == False:
                self.initialize(int_I_delay_m, int_I_delay_s, int_I_delay_ms)
                self.bool_stRunning = True
            elif self.bool_stRunning == True and self.bool_stOutput == False:
                self.updateRunTime()
            if self.int_runTime_ms <= self.int_totalRuntime_ms:
                self.bool_stOutput = False
            elif self.int_runTime_ms > self.int_totalRuntime_ms:
                self.bool_stOutput = True
        elif bool_I_cmdStart == False:
            self.reset()
        return self.bool_stOutput
    
class pulseTimer(timer, edgeDetection):
    
    def __init__(self):
        timer.__init__(self)
        edgeDetection.__init__(self, True)
    
    def run(self, bool_I_cmdStart, int_I_delay_m, int_I_delay_s, int_I_delay_ms):
       bool_startStatus = self.queryEdgeStatus(bool_I_cmdStart)
       if bool_startStatus == True and self.bool_stRunning == False:
           self.initialize(int_I_delay_m, int_I_delay_s, int_I_delay_ms)
           self.bool_stRunning = True
       if self.bool_stRunning == True:
            self.updateRunTime()
            if self.int_runTime_ms <= self.int_totalRuntime_ms:
                self.bool_stOutput = True
            elif self.int_runTime_ms > self.int_totalRuntime_ms:
                self.reset()
       return self.bool_stOutput
    
class pulseGenerator(timer):
    
    def __init__(self):        
        timer.__init__(self)
        
    def run(self, bool_I_cmdStart, int_I_delay_m, int_I_delay_s, int_I_delay_ms):
        if bool_I_cmdStart == True:
            #print("Hi")
            if self.bool_stRunning == False:
                self.initialize(int_I_delay_m, int_I_delay_s, int_I_delay_ms)
                self.bool_stRunning = True
                self.bool_stOutput = True
            else:
                self.updateRunTime()
                if self.int_runTime_ms <= self.int_totalRuntime_ms:
                    pass
                elif self.int_runTime_ms > self.int_totalRuntime_ms:
                    if self.bool_stOutput == False:
                        self.bool_stOutput = True
                        self.initialize(int_I_delay_m, int_I_delay_s, int_I_delay_ms)
                    elif self.bool_stOutput == True:
                        self.bool_stOutput = False
                        self.initialize(int_I_delay_m, int_I_delay_s, int_I_delay_ms)
        elif bool_I_cmdStart == False:
            self.reset()
            #print("He")
        return self.bool_stOutput

            
        


        
        

            
            

        