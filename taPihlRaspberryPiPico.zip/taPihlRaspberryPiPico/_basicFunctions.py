def scale(int_I_inMin, int_I_inMax, int_I_outMin, int_I_outMax, int_I_value):
    int_valueOut = (int_I_outMax - int_I_outMin) * (int_I_value / (int_I_inMax - int_I_inMin))
    return int_valueOut