from machine import Pin, PWM
import _basicFunctions

class digitalPin:
    def __init__(self, bool_I_input, bool_I_output, bool_I_pullUp, int_I_pinNumber):
        self.bool_I_pullUp = bool_I_pullUp
        self.bool_I_input = bool_I_input
        self.bool_I_output = bool_I_output
        self.bool_inputStatus = False
        self.int_pinNumber = int_I_pinNumber
        
        if self.bool_I_input == True and self.bool_I_output == False:
            if self.bool_I_pullUp == True:
                self.Pin = Pin(self.int_pinNumber, Pin.IN, Pin.PULL_UP)
            elif self.bool_I_pullUp == False:
                self.Pin = Pin(self.int_pinNumber, Pin.IN, Pin.PULL_DOWN)
            self.bool_inputPin = True
        elif self.bool_I_input == False and self.bool_I_output == True:
            self.Pin = Pin(self.int_pinNumber, Pin.OUT)
            self.bool_inputPin = False
            
    def readInpin(self):
        if self.bool_inputPin == True:
            if self.Pin.value():
                self.bool_inputStatus = True
            else:
                self.bool_inputStatus = False            
        return self.bool_inputStatus
    
    def writeOutPin(self, bool_I_cmd):
        if self.bool_inputPin == False:
            if bool_I_cmd == True:
                self.Pin.value(1)
                #print("On")
            elif bool_I_cmd == False:
                self.Pin.value(0)
                #print("Off")

class pwmPin:
    def __init__ (self, int_I_frequency, int_I_pinNumber):
        self.int_frequency = int_I_frequency
        self.int_pinNumber = int_I_pinNumber
        self.Pin = PWM(Pin(self.int_pinNumber), freq = self.int_frequency)        
        self.Pin.duty(0)        
    
    def write(self, int_I_dutyCycle_pct):
         int_dutyCycle = _basicFunctions.scale(0, 100, 0, 1023, int_I_dutyCycle_pct)
         int_dutyCycle = 0
         self.Pin.duty(int_dutyCycle)
        

        
        
    
        
    