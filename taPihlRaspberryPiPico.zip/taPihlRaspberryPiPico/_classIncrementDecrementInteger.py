from _classBitLogic import edgeDetection
from _classTimers import onDelayTimer


class incrementDecrementInteger(edgeDetection, onDelayTimer):
    def __init__(self):
        edgeDetection.__init__(self, True, False)
        onDelayTimer.__init__(self, 0, 10, 0)