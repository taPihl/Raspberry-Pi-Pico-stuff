import sys
sys.path.append('/extModules')

import _classDigital_IO
import _classAddIntegerWithRisingEdge
import _classTimers

_classInPin = _classDigital_IO.digitalPin
_classIntegerAdder = _classAddIntegerWithRisingEdge.addIntegerWithRisingEdge
_classOnDelayTimer = _classTimers.onDelayTimer

class ledControl(_classInPin, _classIntegerAdder, _classOnDelayTimer):
    def __init__(self, in_pinNumber):
        self.mode = 0
        self.outPins = [False, False, False, False, False, False, False, False, False, False]
        _classInPin.__init__(self, True, False, False, in_pinNumber)
        _classIntegerAdder.__init__(self, 0, 3)
        _classOnDelayTimer.__init__(self, 0, 1, 0)
        
    def changeMode():
        buttonState = self.readInPin()
        self.mode = self.addInteger(buttonState)
        
    def controlOutpins(self):
        tempOutPins = [False, False, False, False, False, False, False, False, False, False]
        if self.mode == 0: #all off
            pass
        elif self.mode == 1: #all on
            for x in range(9):
                tempOutPins[x] = True
        elif self.mode == 2: #switch on consecutively
            

                    
        
            
        
    
    
    
        
        
