from machine import ADC
import _basicFunctions

class analogPin:
    def __init__(self, int_I_pinNumber, int_I_scaleOutMin, int_I_scaleOutMax):
        self.int_pinNumber = int_I_pinNumber
        self.Pin = ADC(self.int_pinNumber)
        self.int_scaleOutMin = int_I_scaleOutMin
        self.int_scaleOutMax = int_I_scaleOutMax
        
    def initialize(self, int_I_scaleOutMin, int_I_scaleOutMax):
        self.int_scaleOutMin = int_I_scaleOutMin
        self.int_scaleOutMax = int_I_scaleOutMax
        
    def readAnalogPin(self):
        int_reading = self.Pin.read_u16()
        int_scaledValue = _basicFunctions.scale(0, 65535, self.int_scaleOutMin, self.int_scaleOutMax, int_reading)
        return int_scaledValue
    
        
    
    
        
        